# PRÁCTICA 2 - GIT

#### Crea un repositorio (directorio) llamado practica2git e inicializa el sistema de control de versiones 
![](2/1.png)

### Crea un fichero llamado contenido.txt con el siguiente texto:

![](2\2.png)

![](2\comandos.png)

### Comprueba el estado del repositorio:

![](2\3.png)

### Añade el fichero a la zona de preparado.

![](2\4.png)

### Comprueba de nuevo el estado del repositorio

![](2\5.png)

### Hacer el primer commit con su comentario correspondiente

![](2\6.png)

### Añadir la línea al fichero:

![](2\comando2.png)

### Comprueba de nuevo el estado del repositorio.

![](2\8.png)

### Añadir el fichero a preparado
![](2\9.png)

### Hacer otro commit del fichero
![](2\10.png)

### Cambiar el mensaje del último commit por “Añadido la línea de MAC.”

![](2\11.png)



