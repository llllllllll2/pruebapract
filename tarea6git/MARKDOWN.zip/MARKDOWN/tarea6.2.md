#### 0 Inicializad bien vuestro repositorio de Entornos si lo tenéis o bien la carpeta Tarea6-GIT

![](0.png)

#### 1 Cread un fichero test.java con la clase test como sigue

![](1.png)

#### 2 Pasad a preparado el fichero

![](2.png)

#### 3 Cread el fichero Principal.java

![](1.1.png)

#### 4 Pasad a preparado el fichero

![](2.png)

#### 5 Haced un commit con el comentario “Inicial clases test y principal”

![](5.png)

#### 6 Comprobad la salida del programa. (debéis compilar los .java y probar el Principal)



![](compilacionbuena.png)

#### 7 Modificad el fichero test eliminando el método toString()

![](eliminarstring.png)

#### 8 Pasad a preparado el fichero

![](2.png)

#### 9 Realizad un segundo commit “Eliminada ToString()”

![](9%20segundo%20commit.png)

#### 10 Comprobad de nuevo la salida del programa.

![](salida.png)

#### 11 Volved atrás viendo los “log” y haciendo “checkout” necesarios para que la salida del programa sea la del paso 6.

![](oneline.png)

![](cheks.png)

#### ¿Qué creéis que hace el método toString?

El método "toString" se utiliza para convertir cualquier objeto en una cadena de texto.
Al borrarlo de nuestro código, lo que nos muestra es:
En primer lugar, el nombre de nuestra clase.
En segundo lugar, una arroba "@".
Por último, una cifra hexadecimal, con números entre el "0" y "9", y letras entre la "a" y la "f".

#### ¿Qué conseguimos con el @Override?

@Override se utiliza para forzar al compilador a comprobar en tiempo de compilación que un método se está sobrescribiendo correctamente, evitando errores en tiempo de ejecución.

En conclusión, si haces algo mal, detecta mientras compila que no estás cumpliendo con los requisitos para sobrescribir un método.