# PRÁCTICA 3 - GIT

### 1-Entra en el directorio de la práctica2 (practica2git) y a partir de ahí realizaremos esta práctica

![](3/1.png)

### 2-Crea la carpeta "unidades" y dentro de ella un fichero llamado windows1.txt con el siguiente texto:

![](3/2.png)

### 3-Añade los cambios realizados a la zona de preparado

![](3/3.png)

### 4-Hacer un commit con el comentario "Añadido fichero windows1"

![](3/4.png)

### 5-Mostrar de nuevo el historial de cambios del repositorio

![](3/5.png)

### 6-Creal el fichero "windows2.txt" dentro de "unidades" con el texto:

![](3/6.png)

### 7-Añade los cambios a la zona de preparado

![](3/7.png)

### 8-Hacer commit de cambios con el comentario "añadido windows2.txt"

![](3/8.png)

### 9-Mostrad las diferencias entre los dos últimos commits (Esto se explica en clase)

![](3/diferencias.png)




### 10-Añade al fichero windows2.txt las lineas:

![](3/10.2.png)


### 11-Añade los cambios a la zona de preparado

![](3/11.png)

### 12-Commit de los cambios con el comentario "Añadidas versiones a windows2.txt"

![](3/12.png)

### 13-Mostrad quien ha hecho cambios en el fichero windows2.txt

![](3/13.png)