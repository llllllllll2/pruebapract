# TAREA 5
#### 0. Importar el proyecto en vuestro WorkSpace de Eclipse.

#### 1.  Explicar QUÉ HACE EL MÉTODO MAIN.

Crea una variable de tipo int "TAMANYO" con el valor 10.
Después, crea dos arrays te tipo int "lista" y "lista2", con el tamaño de la variable "TAMANYO".

Luego llama a la función "rellenarArrays" para rellenar los datos.

Luego se establece un código para saber cúanto tarda el programa en ejecutarse.

Después llama a la función "intercambio" del array "lista"

Luego establece otro código para saber cuanto tarda el programa en ejecutarse.

Después llama a la función "imprimirArray" para imprimir "lista" y "lista2"

Después vuelve a crear dos códigos "time1 y time2" y entre ellas ordena el array de menor a mayor.


#### 2. Poner un punto de ruptura (breakpoint) en la línea 78 (primer bucle del método intercambio) y,basándoos en los valores que van tomando las variables, explicad cómo funciona el método de ordenación de arrays por intercambio. Podéis crear tablas para ver cómo cambian los valores de los arrays.

Valores del array:  48 77 44  9  81  41  68  46  88  95
Posición array:     0  1  2   3  4   5    6   7   8   9

Empezamos por la línea 78:

Asigna a "I" el valor de "0" y comprueba si es menor o mayor que el tamaño que tiene el array "lista", que en este caso es de 10 números. Como "I = 0" es menor que el tamaño de la lista(10), salta a la siguiente línea del código.

Línea 79:

Aquí, al valor de "J" se le asigna lo que vale "I" + 1, que en este caso es "0". Entonces, J = I+1 ---> J = 0 + 1 ----> J = 1.

Se compara el valor que tiene "J" --> (1) con el número máximo del array lista, que es 10.

Como "J = 1" es menor que el tamaño del array(10), pasamos a la siguiente línea de código.

Línea 80:

Aquí se compara el valor que tiene asignada la I = 0 en ese momento, que es (48) con el valor que tiene la J = 1, que es (77).

En caso de que el valor de "I" fuese menor que el valor de "J", el programa vuelve a la línea anterior, incrementando "J ++ " hasta que el valor de la "I" sea mayor que el valor de la "J". 

Si el valor de la "I" ->(48) es mayor que el valor de la "J" ->(77),
entonces saltamos a la siguiente línea de código.



Línea 82:

En la línea 82 se crea una variable llamada "variableauxiliar" para guardar el valor que tiene la "I" en ese momento. 

Línea 83:

En esta línea, se le asigna a la posición de "I = 0" el valor que tenga la J en ese momento.
Al hacer esto, habríamos perdido el valor que tenía la "I" en ese momoento, pero para solucionarlo habíamos creando en la línea 82 una variable que guardase el valor que tenía la "I". 
Línea 84:

Aquí, se le asigna a la "J" el valor que tenía guardada la variable "variableauxiliar", que recordemos que había perdido su posición en el array al haber sido sustituido por un valor menor.









