### TAREA2

## 1 ¿Qué hace la línea de código en la función 1?

#### La línea uno nos muestra e lvalor de la variable "string2", la cual empieza con un valor de 27.
#### La segunda línea, "string2" pasa a llamarse "string", y aumenta su valor en 1- ---> 28.
#### La tercera línea pasa de llamarse "string" a llamarse "string1", y su valor pasa a ser de 31.

## 2 ¿Qué valen las variables string1 y string2 antes de ejecutar el código de comprobación?

#### La variable String1 vale 20.
#### La veriable String2 vale 27.

## 3 ¿Por qué no funciona el operador == ? ¿Qué operador se debe usar en lugar de este?

#### No funciona porque no se pueden comparar dos strings con el operador " ==".
#### Para comparar dos strings hay que usar el operador "EQUALS"

## 4 ¿Cómo hago la llamada para que funcione?

##### Si queremos hacer la llamada desde el mismo documento, tendremos que añadir "static", quedando así: public static void funcion2()

##### 
